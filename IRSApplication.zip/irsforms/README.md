# MongoJsonLoader

This program will take a large JSON data set and load it into MongoDB

1) You will need to run ./gradlew build

2) You can then run java -jar build/libs/irsforms-0.0.1-SNAPSHOT.jar.
